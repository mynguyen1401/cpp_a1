/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#ifndef STDVECTOR_H
#define STDVECTOR_H

#include <memory>
#include <iostream>
#include <set>
#include <list>
#include <string>
#include <vector>
#include <algorithm>
#include "data_type.h"
class myVector : public data_type
{
	private: 
	std::vector<std::string> avector;
	public:
	bool add(std::string);
	bool search(std::string);
	int get_size();
	void print(void);
	std::string get_list_data(int);

};

#endif
