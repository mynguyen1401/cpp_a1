/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#include "stdvector.h"

using mv = myVector;
// Add data to std::vector
bool mv::add(std::string data)
{
	avector.push_back(data);
	return true;
}
// Iterate and return True if found needle string in the vector
bool mv::search(std::string needle)
{
	std::vector<std::string>::const_iterator iter = 	std::find(avector.begin(), avector.end(), needle) ;
	if(iter != avector.end()) return true;	


	return false;
}
// Return std::vector size
int mv::get_size() 
{
	return avector.size();
}
// Iterate and print out the list
void mv::print()
{
	for (std::vector<std::string>::const_iterator iter = avector.begin(); iter != avector.end(); ++ iter) {
	std::cout << *iter << std::endl;
	}
}
// Iterate the list to the position provided then return data
std::string mv::get_list_data(int num){
	if(avector.size() == 0)
	{
		return 0;
	}
	int count;
	for (std::vector<std::string>::const_iterator iter = avector.begin(); iter != avector.end(); ++ iter) {
		count ++;
		if(count == num) {
			return *iter;
		}
	}
	return "";
}




