/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#include "stdlist.h"

using ml = myList;
// Add data to std::list
bool ml::add(std::string data)
{
	alist.push_back(data);
	return true;
}
// Iterate and return True if found needle string in the list
bool ml::search(std::string needle)
{
	std::list<std::string>::const_iterator iter = 	std::find(alist.begin(), alist.end(), needle) ;
	if(iter != alist.end()) return true;	


	return false;
}
// Return std::list size
int ml::get_size() 
{
	return alist.size();
}
// Iterate and print out the list
void ml::print()
{
	for (std::list<std::string>::const_iterator iter = alist.begin(); iter != alist.end(); ++ iter) {
	std::cout << *iter << std::endl;
	}
}
// Iterate the list to the position provided then return data
std::string ml::get_list_data(int num){
	if(alist.size() == 0)
	{
		return 0;
	}
	int count;
	for (std::list<std::string>::const_iterator iter = alist.begin(); iter != alist.end(); ++ iter) {
		count ++;
		if(count == num) {
			return *iter;
		}
	}
	return "";
}



