/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#ifndef BST_H
#define BST_H

#include <memory>
#include <iostream>
#include "data_type.h"
class BinarySearchTree : public data_type
{
	struct TreeNode; 
	typedef std::unique_ptr<TreeNode> spTreeNode;

	struct TreeNode{
		std::string data;
		spTreeNode left;
		spTreeNode right;
		TreeNode(std::string newdata): data(newdata), left(nullptr), right(nullptr){};
		void setleft(std::unique_ptr<TreeNode>&& newl);
		void setright(std::unique_ptr<TreeNode>&& newr);
		TreeNode *getleft(void);
		TreeNode *getright(void);
		std::string getdata(void);
		std::unique_ptr<TreeNode>& getleftPtr(void);
		std::unique_ptr<TreeNode>& getrightPtr(void);
	};
	class finder{
		int index;
		std::string data;
		void traverse(std::unique_ptr<TreeNode> &cur);
		public:
		finder(): index(0), data("") {}
		friend class BinarySearchTree;	
	};
	
	spTreeNode root;
	int size;
	std::string data = "";
		void print(spTreeNode&);
	public: 
	BinarySearchTree() : root(nullptr), size(0) {};
	bool add(std::string);
	bool search(std::string);
	int get_size();
	void print();
	
	std::string get_list_data(int);
};
#endif
