/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#ifndef MAIN_H
#define MAIN_H

#include <iostream>
#include <map>
#include <string>
#include <set>
#include <boost/program_options.hpp>
#include "list.h"
#include "tree.h"
#include "set.h"
#include "stdlist.h"
#include "stdvector.h"

#include "checker.h"


#endif
