/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <map>
#include <boost/tokenizer.hpp>

#include "list.h"
#include "tree.h"

class checker
{
	std::map<std::string, int> fmatch;
	std::map<std::string, std::string> ufmatch;
	int edit_distance(std::string &, std::string &);
	bool word_count(data_type *, data_type *);	
	public:	
	bool loadfile(data_type *,std::string);
	bool writefile(data_type *, data_type *, std::string);
};
