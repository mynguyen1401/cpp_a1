/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#include "list.h"

using ll=linked_list;
// Single linked list implementation
// Set next node
void ll::node::set_next(std::unique_ptr<ll::node>&& newnext)
{
	next = std::move(newnext);
}

// Get next node
ll::node * ll::node::get_next(void)
{
	return next.get();
}

// Get the next pointer
std::unique_ptr<ll::node>& ll::node::get_next_ptr(void)
{
	return next;
}
// Get data of one node
std::string ll::node::get_data(void)
{
	return data;
}
// Add node to the linked list
bool ll::add(std::string data)
{
	node * current;
	node * prev = nullptr;
	std::unique_ptr<ll::node> newnode = std::make_unique<ll::node>(data);
	// Check if head is null
	if(head == nullptr)
	{
		head = std::make_unique<node>(data);
		++size;
		return true;
	}
	// If head not null, set current node equal with head
	current = head.get(); 
	while(current && current->data < data)
	{ 
		prev = current;
		current = current->get_next();
	}
	if(!prev)
	{
		newnode->set_next(std::move(head));
		head = std::move(newnode);
	}
	else if(!current)
	{
		prev->set_next(std::move(newnode));
	}
	else 
	{
		newnode->set_next(std::move(prev->get_next_ptr()));
		prev->set_next(std::move(newnode));
	}
	++size;
	return true;
}

// Find the needle string in linked list, return True if found
bool ll::search(std::string needle)
{
	ll::node * current;
	for(current = head.get(); current; current = current->get_next())
	{
		if(!current->data.compare(needle)){
			return true;
		}
	}return false;
}

// Return the size of linked list
int ll::get_size() 
{
	return size;
}

// Print out the linked list 
void ll::print(void)
{
	ll::node * current;
	for(current = head.get(); current; current = current->get_next())
	{
		std::cout <<current->data << std::endl;
	}
}

// Loop through the list with provided position and return the data of the current node
std::string ll::get_list_data(int num){
	if(size == 0)
	{
		return 0;
	}
	node * cur = head.get();
	for(int i = 1; i < num; i++){
		cur = cur->get_next();
	}
	return cur->get_data();
}

