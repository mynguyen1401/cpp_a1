/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#ifndef DATATYPE_H
#define DATATYPE_H

 //defining a data_structure class
class data_type
{
	public:
		virtual bool add(std::string) = 0;
		
		virtual bool search(std::string) = 0;
		
		virtual int get_size() = 0;
		
		virtual void print(void) = 0;
		virtual std::string get_list_data(int) = 0;
};

#endif 
