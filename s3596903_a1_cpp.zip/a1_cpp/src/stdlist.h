/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#ifndef STDLIST_H
#define STDLIST_H

#include <memory>
#include <iostream>
#include <set>
#include <list>
#include <string>
#include <algorithm>
#include "data_type.h"
class myList : public data_type
{
	private: 
	std::list<std::string> alist;
	public:
	bool add(std::string);
	bool search(std::string);
	int get_size();
	void print(void);
	std::string get_list_data(int);

};

#endif

