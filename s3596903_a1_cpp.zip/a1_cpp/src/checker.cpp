/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
//checker.cpp / checker.h - has the implementation of the loading of each file into the specific data structure and the comparison with the dictionary including computing the edit distance to find the closest word in the dictionary.
#include "checker.h"

using namespace std;
// Open and load data from the file into the provided datastructures 
bool checker::loadfile(data_type *datastructure, std::string filename) {
	
	std::ifstream in(filename);
	if(!in){
		// Return error message if file cannot be opened
		std::cout << "Cannot open file!" << std::endl;
		return false;
	}
	std::string line;
	// Read lines
	while(std::getline(in, line)) {
		// Seperate words with symbol, carriage return etc,..
		boost::tokenizer<> token(line);
		for(boost::tokenizer<>::iterator word=token.begin(); word!= token.end(); ++word) {
			// Add word into the datastructure provided
			datastructure->add(*word);
		}
	}
	// Close after open
	in.close();
	return true;
}

// Levenshtein distance, takes two strings as parameters
int checker::edit_distance(std::string &string1, std::string &string2) {
	 int dist[255][255];
	 for(int i = 1; i <= (int)string1.length(); i++)
	 {
		 dist[i][0] = i;
	 }
	 for(int j = 1; j <= (int)string2.length(); j++)
	 {
		 dist[0][j] = j;
	 }
	 
	 for(int j = 1; j <= (int)string2.length(); j++)
	 {
		 for(int i = 1; i <= (int)string1.length(); i++)
		 {
			 if(string1[i-1] == string2[j-1])
			 {
				 dist[i][j] = dist[i-1][j-1];
			 }
			 else
			 {
				 dist[i][j] = std::min(dist[i-1][j-1] + 1, std::min(dist[i][j-1] + 1, dist[i-1][j] + 1));
			 }
		 }
	 }
	 return dist[string1.length()][string2.length()];
}

// Count words in textfile that appear in the dictionary, if not called the levenshtein function to find another match
bool checker::word_count(data_type *dictionary, data_type *textfile) {
	map<string, int> map_count;
	map<string, int>::iterator it;
	// Loop through all the word in the textfile 
	for(int i = 1; i < textfile->get_size(); i++)
	{
		// Get a word
		string text_data = textfile->get_list_data(i);
		// Find it in the dictionary
		if(dictionary->search(text_data))
		{
			it = fmatch.find(text_data);
			if(it != fmatch.end())
			{
				it->second++;
			}
			else
			{
				fmatch.insert(pair<string, int>(text_data, 1));
			}
		}
		else
		{ // If that word is not appeared in the dictionary list
			int min = 0;
			map_count.clear();
			std::string temp_string = "";
			// Loop through the dictionary list and called edit_distance function to find another match of word
			for(int i = 1; i < dictionary->get_size(); i++)
			{ 
				string dict_data = dictionary->get_list_data(i);
				int distance =  edit_distance(text_data, dict_data);
				if(i == 1) {
					min = distance;
				}
				if(distance <= min) {
					min = distance;
					map_count.insert(pair<string, int>(dict_data, min));
				}
			}
			it = map_count.begin();
			while(it != map_count.end())
			{
				if(it->second != min)
				{
					map_count.erase(it);
				}
				it++;
			}
			it = map_count.begin();
			while(it != map_count.end())
			{
				temp_string += it->first + ". ";
				it++;
			}
			ufmatch.insert(pair<string, string>(text_data, temp_string));
		}
	}
	return true;
}
// Write the output file 
bool checker::writefile(data_type *dictionary, data_type *textfile, string filename) 
{
	map<string, int>::iterator match;
	map<string, string>::iterator unmatch;
	ofstream outFile(filename);
	// Check if output file is null
	if(!outFile) {
		std::cout << "Cannot create outfile!" << std::endl;
		return false;
	}
	word_count(dictionary, textfile);
	match = fmatch.begin();
	while(match != fmatch.end())
	{
		outFile << match->first << ": " << match->second << std::endl;
		match++;
	}
	unmatch = ufmatch.begin();
	while(unmatch != ufmatch.end()){
		outFile << unmatch->first << ": was not found. Found: " << unmatch->second << std::endl;
		unmatch++;
	}
	fmatch.clear();
	ufmatch.clear();
	outFile.close();
	return true;
}

