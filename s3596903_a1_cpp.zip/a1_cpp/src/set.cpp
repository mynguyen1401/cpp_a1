/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#include "set.h"

using ms = mySet;
// Add data to set
bool ms::add(std::string data)
{
	multiset.insert(data);
	return true;
}

// Search for the needle String inside std::set
bool ms::search(std::string needle)
{
	if(multiset.find(needle) != multiset.end()) return true;
	return false;
}
// Return the size of the set
int ms::get_size() 
{
	return multiset.size();
}
// interate the set and print out the data
void ms::print()
{
	for (std::multiset<std::string>::const_iterator iter = multiset.begin(); iter != multiset.end(); ++ iter) {
	std::cout << *iter << std::endl;
	}
}
// Iterate the set to a provided position and then return data 
std::string ms::get_list_data(int num){
	if(multiset.size() == 0)
	{
		return 0;
	}
	int count;
	for (std::multiset<std::string>::const_iterator iter = multiset.begin(); iter != multiset.end(); ++ iter) {
		count ++;
		if(count == num) {
			return *iter;
		}
	}
	return "";
}


