/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#include "main.h"
//main.cpp - contains main and the handling command line arguments although the command line parser could be in a different file. 

using namespace std;

int main(int argc, char **argv)
{
	namespace po = boost::program_options;
	// Create strings to stores input information
	std::string datastructures;
	std::string dictionaries;
	std::string textfiles;
	std::string outputs;
	// Create options 
	po::options_description desc("Options");

	desc.add_options()
    	("help,h", "produce help message")
    	("datastructure,s", po::value<std::string>(),"datastructure: list, vector, set, custom_list, custom_tree")
	("dictionary,d", po::value<std::string>(),"dictionary file path")
	("textfile,t", po::value<std::string>(), "textfile path")
	("output,o", po::value<std::string>(), "output file path");

	po::variables_map vm;
	po::store(po::command_line_parser(argc, argv).options(desc).run(), vm);
	po::notify(vm);    

	if (vm.count("help")) {
    		cout << desc << endl;
	};
	if(vm.count("datastructure")) {
		datastructures = vm["datastructure"].as<std::string>();
	}
	if(vm.count("dictionary")) {
		dictionaries = vm["dictionary"].as<std::string>();
	}
	if(vm.count("textfile")) {
		textfiles = vm["textfile"].as<std::string>();
	}
	if(vm.count("output")) {
		outputs = vm["output"].as<std::string>();
	}
	
	// Create checker object and 2 datatype for textfile and dictionary file
	checker checker;
	data_type *text;
	data_type *dict;
	// Compare string input with data_type name
	if(datastructures.compare("custom_list") == 0) {
		
		text = new linked_list();
		dict = new linked_list();
	}
	else if(datastructures.compare("custom_tree") == 0) {
	
		text = new BinarySearchTree();
		dict = new BinarySearchTree();
	
	}
	else if(datastructures.compare("set") == 0) {
		
		text = new mySet();
		dict = new mySet();

	}
	else if(datastructures.compare("list") == 0) {
		text = new myList();
		dict = new myList();

	}
	else if(datastructures.compare("vector") == 0) {
		text = new myVector();
		dict = new myVector();
	}else {
		std::cout << "Error input data_type" << std::endl;
	}
	
	// Check if create data_type successfull and load file into data_type have just created
	if(dict != nullptr && text != nullptr) {
		checker.loadfile(dict, dictionaries);
		
		checker.loadfile(text, textfiles);
		
		
	}
	// Write the list into output file
	if(checker.writefile(dict, text, outputs)) {
		return 0;
	}

	return 1;
}
