/*COSC1254-Programming using C++
ASSIGNMENT1-semester2-2017
Name: My Nguyen
Student ID: s3596903*/
#include "tree.h"

using bst =  BinarySearchTree;
// Set the left node
void bst::TreeNode::setleft(std::unique_ptr<bst::TreeNode>&& newl)
{
	left = std::move(newl);
}
// Set the right node
void bst::TreeNode::setright(std::unique_ptr<bst::TreeNode>&& newr)
{
	right = std::move(newr);
}
// Get the left node
bst::TreeNode * bst::TreeNode::getleft(void)
{
	return left.get();
}
// Get the right node
bst::TreeNode * bst::TreeNode::getright(void)
{
	return right.get();
}
// Get the data
std::string bst::TreeNode::getdata(void)
{
	return data;
}
// Get the right pointer
std::unique_ptr<bst::TreeNode>& bst::TreeNode::getrightPtr(void)
{
	return right;
}
// Get the left pointer
std::unique_ptr<bst::TreeNode>& bst::TreeNode::getleftPtr(void)
{
	return left;
}
// Add data to the tree
bool bst::add(std::string data)
{
	std::unique_ptr<TreeNode> node = std::make_unique<TreeNode>(data);
	// Check if root null	
	if(root == nullptr) {
		root = std::move(node);
		size++;
		return true;
	}
	TreeNode* temp = root.get();
	TreeNode* prev = nullptr;
	while (temp != nullptr){
	prev = temp;
	if(data.compare(temp->data) < 0) {
		temp = temp->getleft();
		if(temp == nullptr){
			prev->setleft(std::move(node));
			size++;
			return true;
		}
	}else {
		temp = temp->getright();
		if(temp == nullptr){
			prev->setright(std::move(node));
			size++;
			return true;
		}
	}
	}
	return false;
}
// Search data in the tree 
bool bst::search(std::string data)
{
	TreeNode * current = root.get();
	while(current)
	{
		if(data.compare(current->data) == 0)
		{
			return true;
		}
		else if(data.compare(current->data) < 0)
		{
			current = current->left.get();
		}
		else
		{
			current = current->right.get();
		}
		
	}
	return false;
}
// Retunr size of tree
int bst::get_size()
{
	return size;
}
// Print out the root
void bst::print()
{
	print(root);
}
// Print the child node of root
void bst::print(std::unique_ptr<TreeNode> &node)
{
	if(node == nullptr) return;
	print(node->left);
	std::cout << node->data << std::endl;
	print(node->right);
}
// Iterate the tree
void bst::finder::traverse(std::unique_ptr<bst::TreeNode> &cur)
{
	if(cur == nullptr || data != "")
	{ return;
	}traverse(cur->getleftPtr());
	index--;
	if(index == 0){
		data = cur->getdata();
	}
	traverse(cur->getrightPtr());
	
}
// Iterate until num position
std::string bst::get_list_data(int num)
{
	finder finder;
	finder.index = num;
	finder.data = "";
	finder.traverse(root);
	return finder.data;
}

